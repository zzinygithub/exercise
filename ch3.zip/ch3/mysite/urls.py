# from django.urls import path
# from polls import views
# from django.contrib import admin

# app_name = 'polls'
# urlpatterns = [
#     path('admin/', admin.site.urls),
#     path('polls/', views.index, name='index'),     
#     path('polls/<int:question_id>/', views.detail, name='detail'),      
#     path('polls/<int:question_id>/results/', views.results, name='results'),    
#     path('polls/<int:question_id>/vote/', views.vote, name='vote'),    
# ]
from django.contrib import admin
from django.urls import path
from django.urls import include
from mysite import views

urlpatterns = [
    path('admin/', admin.site.urls),

    path('', views.HomeView.as_view(), name='home'),
    path('polls/', include('polls.urls')),
    path('books/', include('books.urls')),
]
