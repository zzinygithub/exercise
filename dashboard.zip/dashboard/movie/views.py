from django.shortcuts import render
from django.http import HttpResponse



def index(request):
    return HttpResponse("영화블로그에 오신것을 환영합니다~^^;")

def review(request):
    return render(request,'review.html')

