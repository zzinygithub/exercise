from django.views.generic import ListView, DetailView ,CreateView
from bookmark.models import Bookmark
from django.contrib.auth.mixins import LoginRequiredMixin
from django.urls import reverse_lazy


class BookmarkListView(ListView):
    model = Bookmark
class BookmarkDetailView(DetailView):
    model = Bookmark

class BookmarkCreateView(LoginRequiredMixin,CreateView):
    model = Bookmark
    fields = ['title', 'url'] 
    success_url = reverse_lazy('bookmark:index')

    def form_valid(self, form):
        form.instance.owner = self.request.user
        return super().form_valid(form)

